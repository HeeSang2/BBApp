package com.example.blackbox_v10;

public class DataQuestion {
    String title;
    String anwser;

    public DataQuestion(String title, String anwser){

        this.title = title;
        this.anwser = anwser;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAnwser() {
        return anwser;
    }

    public void setAnwser(String anwser) {
        this.anwser = anwser;
    }

}
