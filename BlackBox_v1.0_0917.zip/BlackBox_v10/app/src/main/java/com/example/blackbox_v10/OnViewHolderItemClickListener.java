package com.example.blackbox_v10;

public interface OnViewHolderItemClickListener {
    void onViewHolderItemClick();
}
