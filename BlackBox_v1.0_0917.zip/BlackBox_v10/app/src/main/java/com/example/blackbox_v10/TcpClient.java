package com.example.blackbox_v10;


import android.os.Handler;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.InetSocketAddress;
import java.net.Socket;
public class TcpClient implements Serializable {
    private Socket socket;
    private OutputStream socketOutput;
    private BufferedReader socketInput;
    private String message;
    private String ip;
    private String port;
    private ClientCallback listener=null;
    private double latitude=36.80766;  //위도
    private double longitude=127.16360;
    Handler handler;
    public TcpClient(){}

    public TcpClient(String ip,String port,Handler handler){
        this.ip = ip;
        this.port = port;
        this.handler=handler;
    }


    public String getMessage() {
        return message ;
    }
    public double getLatitude() {
        return latitude;
    }
    public double getLongitude() {
        return longitude;
    }
    public void connect(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                socket = new Socket();
                InetSocketAddress socketAddress = new InetSocketAddress(ip, Integer.parseInt(port));

                Log.i("hun", "TCPClient run 안입니다~ ip="+ip+ "port = "+ Integer.parseInt(port));
                try {
                    socket.connect(socketAddress);
                    socketOutput = socket.getOutputStream();
                    socketInput = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                    new ReceiveThread().start();

                    if(listener!=null)
                        listener.onConnect(socket);
                } catch (IOException e) {
                    if(listener!=null)
                        listener.onConnectError(socket, e.getMessage());
                }
            }
        }).start();
    }

    public void disconnect(){
        try {
            socket.close();
        } catch (IOException e) {
            if(listener!=null)
                listener.onDisconnect(socket, e.getMessage());
        }
    }

    public void send(final String message){
        new Thread()
        {
            public void run()
            {
                try {
                    socketOutput.write(message.getBytes());
                } catch (IOException e) {
                    if(listener!=null)
                        listener.onDisconnect(socket, e.getMessage());
                }
            }
        }.start();

    }

    public class ReceiveThread extends Thread implements Runnable{
        public void run(){
            String fullString ;
            String[] splitText=new String[3];

            try {
                while((message = socketInput.readLine()) != null) {   // each line must end with a \n to be received
                    Log.i("hun",message);
                    if(message.equals("-1")){
                        handler.sendEmptyMessage(0);
                    }
                    fullString=message;
                    splitText=fullString.split("-");
                    if(splitText[0].equals("차량위치")){
                        latitude = Double.parseDouble(splitText[1]);
                        longitude = Double.parseDouble(splitText[2]);
                    }

                }

            } catch (IOException e) {
                if(listener!=null)
                    listener.onDisconnect(socket, e.getMessage());
            }

        }
    }

    public void setClientCallback(ClientCallback listener){
        this.listener=listener;
    }

    public void removeClientCallback(){
        this.listener=null;
    }

    public interface ClientCallback {
        void onMessage(String message);
        void onConnect(Socket socket);
        void onDisconnect(Socket socket, String message);
        void onConnectError(Socket socket, String message);
    }
}